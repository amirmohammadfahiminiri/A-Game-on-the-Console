﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class DrawMainGround
    {
        public DrawMainGround() { }

        static string state = "signup";
        string? temp { get; set; }
        static int width = 30;
        static int height = 15;

        void SetTemp(string? temp)
        {
            if (temp == "LeftArrow" || temp == "RightArrow")
            {
                this.temp = temp;
            }
        }
        public string GetState()
        {
            return state;
        }
        public void ResetState()
        {
            state = "reset";
        }
        public static int GetWidth()
        {
            return width;
        }
        public static int GetHeight()
        {
            return height;
        }
        public void DrawSelection(string? temp)
        {
            SetTemp(temp);
            if (this.temp == "LeftArrow")
            {
                state = "signup";
                Console.Write("*SIGN UP*");
                Console.Write("                 ");
                Console.Write("log in");
            }
            else if (this.temp == "RightArrow")
            {
                state = "login";
                Console.Write("sign up");
                Console.Write("                 ");
                Console.Write("*LOG IN*");
            }
        }
        public void DrawSelection()
        {
            SetTemp("LeftArrow");
            if (temp == "LeftArrow")
            {
                state = "signup";
                Console.Write("*SIGN UP*");
                Console.Write("                 ");
                Console.Write("log in");
            }
            else if (temp == "RightArrow")
            {
                state = "login";
                Console.Write("sign up");
                Console.Write("                 ");
                Console.Write("*LOG IN*");
            }
        }
        public void DrawAnSquare(Babaee b, Food f)
        {
            Console.WriteLine("Your Score is: " + b.GetScore());
            for (int i = 0; i <= height; i++)
            {
                if (i == 0 || i == height)
                {
                    for (int j = 0; j < width; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine("*");
                }
                else
                {
                    Console.Write("*");
                    for (int j = 1; j < width; j++)
                    {
                        if (b.GetX() == j && b.GetY() == i)
                        {
                            Console.OutputEncoding = Encoding.UTF8;
                            Console.Write("\u263A");//\u263A//\u265A
                        }
                        else if (f.GetX() == j && f.GetY() == i)
                        {
                            Console.OutputEncoding = Encoding.UTF8;
                            Console.Write("\u265A");//\u263A//\u265A
                        }
                        else
                        {
                            Console.Write(" ");
                        }
                    }
                    Console.WriteLine("*");
                }
            }
        }
    }
}