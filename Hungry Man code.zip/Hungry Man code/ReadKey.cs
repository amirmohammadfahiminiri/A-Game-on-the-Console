﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class ReadKey
    {
        public static string? ConsoleReadKey()
        {
            ConsoleKeyInfo cki = new ConsoleKeyInfo();

            //while (Console.KeyAvailable == false)
            //    Thread.Sleep(250); // Loop until input is entered.
            cki = Console.ReadKey();
            Console.Clear();
            return Convert.ToString(cki.Key);
        }
    }
}