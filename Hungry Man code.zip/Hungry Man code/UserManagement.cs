﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class UserManagement
    {
        public UserManagement()
        {
            emailAdress = "";
            password = "";
            firstName = "";
            lastName = "";
            userID = "";
            username = "";
        }

        string emailAdress { get; set; }
        string password { get; set; }
        string firstName { get; set; }
        string lastName { get; set; }
        string userID { get; set; }
        string username { get; set; }

        public static string[] GetUserParameters()
        {
            string[] parameters = {"Email Adress: ", "Password: ", "First Name: ", "Last Name: ", "User ID: ", "Username: "};
            return parameters;
        }
        public string GetEmailAdress()
        {
            return emailAdress;
        }
        public string GetPassword()
        {
            return password;
        }
        public string GetFirstName()
        {
            return firstName;
        }
        public string GetLastName()
        {
            return lastName;
        }
        public string GetUserID()
        {
            return userID;
        }
        public string GetUsername()
        {
            return username;
        }
        public string[] GetUserInfo()
        {
            string[] userInfo = new string[6] ;
            userInfo[0] = GetEmailAdress();
            userInfo[1] = GetPassword();
            userInfo[2] = GetFirstName();
            userInfo[3] = GetLastName();
            userInfo[4] = GetUserID();
            userInfo[5] = GetUsername();
            return userInfo;
        }
        public bool UserSignUpConfirm(string? emailAdress, string? password, string? firstName, string? lastName, string? userID, string? username)//is working correctly
        {
            if (emailAdress == null)
            {
                emailAdress = "";
            }
            if (password == null)
            {
                password = "";
            }
            if (firstName == null)
            {
                firstName = "";
            }
            if (lastName == null)
            {
                lastName = "";
            }
            if (userID == null)
            {
                userID = "";
            }
            if (username == null)
            {
                username = "";
            }
            bool flag = false;
            if (EmailAdressConfirm(emailAdress) &&
                PasswordConfirm(password) &&
                FirstNameConfirm(firstName) &&
                LastNameConfirm(lastName) &&
                UserIDConfirm(userID) &&
                UserNameConfirm(username))
            {
                flag = true;
                this.emailAdress = emailAdress;
                this.password = password;
                this.firstName = firstName;
                this.lastName = lastName;
                this.userID = userID;
                this.username = username;
            }
            return flag;
        }
        public bool[] userSignUpError(string? emailAdress = "", string? password = "", string? firstName = "", string? lastName = "", string? userID = "", string? username = "")
        {
            bool[] flags = { false, false, false, false, false, false };
            if (EmailAdressConfirm(emailAdress))
            {
                flags[0] = true;
            }
            if (PasswordConfirm(password))
            {
                flags[1] = true;
            }
            if (FirstNameConfirm(firstName))
            {
                flags[2] = true;
            }
            if (LastNameConfirm(lastName))
            {
                flags[3] = true;
            }
            if (UserIDConfirm(userID))
            {
                flags[4] = true;
            }
            if (UserNameConfirm(username))
            {
                flags[5] = true;
            }
            return flags;
        }
        bool EmailAdressConfirm(string? emailAdress)
        {
            //can be added to --> this.emailAdress = emailAdress;
            bool flag = false;
            flag = true;
            return flag;
        }
        bool PasswordConfirm(string? password)//is working correctly
        {
            if (password == null)
            {
                password = "";
            }
            //can be added to --> this.password = password;
            bool flag = false;
            if (password.Length >= 8 && password.Length <= 20)
            {
                flag = true;
            }
            return flag;
        }
        bool FirstNameConfirm(string? firstName)//is working correctly
        {
            if (firstName == null)
            {
                firstName = "";
            }
            //can be added to --> this.firstName = firstName;
            bool flag = false;
            Regex r = new Regex(@"[0-9]");
            if (firstName.Length >= 2 && firstName.Length <= 20 && !r.IsMatch(firstName))
            {
                flag = true;
            }
            return flag;
        }
        bool LastNameConfirm(string? lastName)//is working correctly
        {
            if (lastName == null)
            {
                lastName = "";
            }
            //can be added to --> this.lastName = lastName;
            bool flag = false;
            Regex r = new Regex(@"[0-9]");
            if (lastName.Length >= 2 && lastName.Length <= 20 && !r.IsMatch(lastName))
            {
                flag = true;
            }
            return flag;
        }
        // userName amd userId is same for now
        bool UserIDConfirm(string? userID)//is working correctly
        {
            if (userID == null)
            {
                userID = "";
            }
            //can be added to --> this.useID = userID;
            bool flag = false;
            if (userID.Length >= 2 && userID.Length <= 20)
            {
                flag = true;
            }
            return flag;
        }
        bool UserNameConfirm(string? username)//is working correctly
        {
            if (username == null)
            {
                username = "";
            }
            //can be added to --> this.userName = userName;
            bool flag = false;
            if (username.Length >= 2 && username.Length <= 20)
            {
                flag = true;
            }
            return flag;
        }
        void GetInfoFromUser()
        {
            //ToDo
        }
        /*public string UserLogInConfirm(string? userIdentity, string? userPassword)
        {
            string userStatus;
            bool[] searchForUser = WorkingWithFiles.SearchforUserInDB(userIdentity, userPassword);
            if (searchForUser[0] && searchForUser[1])
            {
                userStatus = "confirmed";
            }
            else if (searchForUser[0] && !searchForUser[1])
            {
                userStatus = "incorrect password";
            }
            else
            {
                userStatus = "incorrect user identifier";
            }
            return userStatus;
        }*/
    }
}