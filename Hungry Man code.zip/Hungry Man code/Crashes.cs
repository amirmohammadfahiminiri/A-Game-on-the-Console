﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Crashes
    {
        public Crashes() { }
        public bool ObjectsCrash(Babaee b, Food f, DrawMainGround d)
        {
            bool flag = false;
            if (b.GetX() == f.GetX() && b.GetY() == f.GetY())
            {
                f.RandomLocationX();
                f.RandomLocationY();
                b.IncreaseScore();
                Console.Beep();
                flag = true;
            }
            return flag;
        }
    }
}