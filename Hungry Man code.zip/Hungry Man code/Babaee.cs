﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Babaee
    {
        public Babaee()
        {
            score = 0;
            x = 8;
            y = 6;
        }
        protected int moveValue = 1;
        int score { get; set; }
        int x { get; set; }
        int y { get; set; }

        public int GetScore()
        {
            return score;
        }
        public void ResetScore()
        {
            score = 0;
        }
        public void IncreaseScore()
        {
            score++;
        }
        public int GetX()
        {
            return this.x;
        }
        public int GetY()
        {
            return this.y;
        }
        public bool GameOver()
        {
            bool flag = true;
            int horizontalLocation = 5; // افقی یا x
            int verticalLocation = 5; //عمودی یا y
            verticalLocation = this.y;
            horizontalLocation = this.x;
            if (verticalLocation >= DrawMainGround.GetHeight() || horizontalLocation >= DrawMainGround.GetWidth() || verticalLocation <= 0 || horizontalLocation <= 0)
            {
                flag = false;
            }
            return flag;
        }
        public bool Win()
        {
            bool flag = false;
            if (GetScore() == 5)
            {
                flag = true;
            }
            return flag;
        }
        public void HorizontalMove(string temp)
        {
            if (temp == "RightArrow")
            {
                this.x += moveValue;
            }
            if (temp == "LeftArrow")
            {
                this.x -= moveValue;
            }
        }
        public void VerticalMove(string temp)
        {
            if (temp == "DownArrow")
            {
                this.y += moveValue;
            }
            if (temp == "UpArrow")
            {
                this.y -= moveValue;
            }
        }
    }
}