﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Food
    {
        public Food()
        {
            RandomLocationX();
            RandomLocationY();
        }
        int x { get; set; }
        int y { get; set; }
        public int GetX()
        {
            return this.x;
        }
        public int GetY()
        {
            return this.y;
        }
        public void RandomLocationX()
        {
            Random rnd = new Random();
            x = rnd.Next(1, DrawMainGround.GetWidth());
        }
        public void RandomLocationY()
        {
            Random rnd = new Random();
            y = rnd.Next(1, DrawMainGround.GetHeight());
        }
    }
}