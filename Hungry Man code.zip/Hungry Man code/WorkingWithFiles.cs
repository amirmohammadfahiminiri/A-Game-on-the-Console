﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class WorkingWithFiles
    {
        public WorkingWithFiles() { }
        //static int usersCount = Convert.ToInt32(File.ReadAllText(GetUsersCountDBPath()));
        static string userInfoDBPath { get; set; }
        static string userCountDBPath { get; set; }

        public static string GetUserInfoDBPath()
        {
            //userInfoDBPath = "D:\\Users\\home\\Desktop\\DBConsoleApp5\\DBTextFileForConsoleApp5.txt";
            userInfoDBPath = "C:/Users/Lenovo/DBTextFileForConsoleApp5.txt";
            return userInfoDBPath;
        }

        public static string GetUsersCountDBPath()
        {
            //userCountDBPath = "D:\\Users\\home\\Desktop\\DBConsoleApp5\\UsersCountDBTextFileForConsoleApp5.txt";
            userCountDBPath = "C:/Users/Lenovo/UsersCountDBTextFileForConsoleApp5.txt";
            return userCountDBPath;
        }

        FileStream CreateFile()
        {
            FileStream fs = new FileStream(/*GetUserInfoDBPath()*/"C:/Users/Lenovo/DBTextFileForConsoleApp5.txt", FileMode.OpenOrCreate, FileAccess.Write);
            return fs;
        }

        string Content(string[] userInfo)
        {
            string content = "";
            for (int i = 0; i < userInfo.Length; i++)
            {
                string[] userParameters = UserManagement.GetUserParameters();
                content += userParameters[i];
                content += userInfo[i];
                content += "\r\n";
            }
            return content;
        }

        //static string StarsLine(int count)
        //{
        //    string stars = "";
        //    for (int i = 0; i < count; i++)
        //    {
        //        stars += "*";
        //    }
        //    usersCount++;
        //    File.WriteAllText("C:/Users/Lenovo/UsersCountDBTextFileForConsoleApp5.txt"/*GetUsersCountDBPath()*/, Convert.ToString(usersCount));
        //    stars += usersCount;
        //    stars += "\r\n";
        //    return stars;
        //}

        /*public void WriteSomeContents(String[] userInfo)
        {
            string existingContent = File.ReadAllText(GetUserInfoDBPath());
            FileStream fs = CreateFile();
            //byte[] info = new UTF8Encoding(true).GetBytes(Content(userInfo));
            //fs.Write(info, 0, info.Length);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(existingContent);
            sw.Write(StarsLine(16));
            sw.Write(Content(userInfo));
            sw.Close();
            fs.Close();
        }/*/

        /*public static bool[] SearchforUserInDB(string? userIdentity = "",string? userPassword = "")
        {
            string? identifier = userIdentity;
            string? password = userPassword;
            string[] allLines;
            bool[] returnValue = new bool[2];
            returnValue[0] = false;
            returnValue[1] = false;
            allLines = File.ReadAllLines(GetUserInfoDBPath());
            for (int starsLine = 0; starsLine < allLines.Length; starsLine += 7)
            {
                if (allLines[starsLine + 1] == "Email Adress: " + identifier || allLines[starsLine + 6] == "Username: " + identifier)
                {
                    returnValue[0] = true;
                    if (allLines[starsLine + 2] == "Password: " + password)
                    {
                        returnValue[1] = true;
                    }
                    break;
                }
            }
            return returnValue;
        }*/
    }
}