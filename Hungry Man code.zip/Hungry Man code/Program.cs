﻿namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true/*ReadKey.ConsoleReadKey() != "Escape"*/)
            {
                string? userIdentifier = "";
                string? emailAdress = "";
                string? password = "";
                string? firstName = "";
                string? lastName = "";
                string? userID = "";
                string? username = "";
                string? logInState = "";
                string? temp = "";
                bool flag = false;
                //Creating Objects
                UserManagement user = new UserManagement();
                Babaee babaee = new Babaee();
                Food apple = new Food();
                Crashes crashes = new Crashes();
                DrawMainGround mainGround = new DrawMainGround();
                WorkingWithFiles workingWithFiles = new WorkingWithFiles();
                //Create File
                /*if (!File.Exists(WorkingWithFiles.GetUserInfoDBPath()))
                {
                    File.Create(WorkingWithFiles.GetUserInfoDBPath());
                }
                if (!File.Exists(WorkingWithFiles.GetUsersCountDBPath()))
                {
                    File.Create(WorkingWithFiles.GetUsersCountDBPath());
                    File.WriteAllText(WorkingWithFiles.GetUsersCountDBPath(), "0");

                }*/
                //sign up and login station
                //while (!flag)
                //{
                //    //Draw first log in or sign up Selection menu
                //    mainGround.DrawSelection();
                //    //Draw log in or sign up Selection menu
                //    while (temp != "Enter")
                //    {
                //        temp = ReadKey.ConsoleReadKey();
                //        mainGround.DrawSelection(temp);
                //    }
                //    Console.Clear();
                //    //to get and check user sign up informations
                //    if (mainGround.GetState() == "signup")
                //    {
                //        //to Get informations from Console user to sign up
                //        for (int i = 0; i < 30; i++)
                //        {
                //            Console.Write("*");
                //            if (i == 29)
                //            {
                //                Console.WriteLine();
                //            }
                //        }
                //        Console.Write("Enter your Email Adress: ");
                //        emailAdress = Console.ReadLine();
                //        Console.Write("Enter your Password: ");
                //        password = Console.ReadLine();
                //        Console.Write("Enter your First Name: ");
                //        firstName = Console.ReadLine();
                //        Console.Write("Enter your Last Name: ");
                //        lastName = Console.ReadLine();
                //        Console.Write("Enter your User ID: ");
                //        userID = Console.ReadLine();
                //        Console.Write("Enter your Username: ");
                //        username = Console.ReadLine();
                //        //for (int i = 0; i < 30; i++)
                //        //{
                //        //    Console.Write("*");
                //        //    if (i == 29)
                //        //    {
                //        //        Console.WriteLine();
                //        //    }
                //        //}
                //        //checking user input sign up informations
                //        /*if (user.UserSignUpConfirm(emailAdress, password, firstName, lastName, userID, username))
                //        {
                //            Console.WriteLine("Succesfully Signed up!");
                //            flag = true;
                //            //ToDoAndWriteInformationsInFile
                //            workingWithFiles.WriteSomeContents(user.GetUserInfo());
                //            Thread.Sleep(1000);
                //        }*/
                //        //else
                //        //{
                //            bool[] flags = user.userSignUpError(emailAdress, password, firstName, lastName, userID, username);
                //            if (flags[0] == false)
                //            {
                //                Console.WriteLine("Invalied Email Adress!");
                //            }
                //            if (flags[1] == false)
                //            {

                //                Console.WriteLine("Invalied Password!");
                //            }
                //            if (flags[2] == false)
                //            {

                //                Console.WriteLine("Invalied Firstname!");
                //            }
                //            if (flags[3] == false)
                //            {

                //                Console.WriteLine("Invalied Lastname!");
                //            }
                //            if (flags[4] == false)
                //            {

                //                Console.WriteLine("Invalied User ID!");
                //            }
                //            if (flags[5] == false)
                //            {

                //                Console.WriteLine("Invalied Username!");
                //            }
                //            Thread.Sleep(1500);
                //            Console.Clear();
                //        //}
                //    }
                //    //checking user input log in informations
                //    else if (mainGround.GetState() == "login")
                //    {
                //        for (int i = 0; i < 30; i++)
                //        {
                //            Console.Write("*");
                //            if (i == 29)
                //            {
                //                Console.WriteLine();
                //            }
                //        }
                //        Console.Write("Enter Username or Email Adress: ");
                //        userIdentifier = Console.ReadLine();
                //        Console.Write("Enter Password: ");
                //        password = Console.ReadLine();
                //        for (int i = 0; i < 30; i++)
                //        {
                //            Console.Write("*");
                //            if (i == 29)
                //            {
                //                Console.WriteLine();
                //            }
                //        }
                //        //logInState = user.UserLogInConfirm(userIdentifier, password);
                //        if (logInState == "confirmed")
                //        {
                //            Console.WriteLine("Succesfully Loged in");
                //            flag = true;
                //            Thread.Sleep(1000);
                //        }
                //        else if (logInState == "incorrect password")
                //        {
                //            //Console.WriteLine("Incorrect Password!");
                //            Console.WriteLine("Incorrect Username or Password!");//for more user security
                //            Thread.Sleep(1000);
                //            //Console.ReadLine();
                //        }
                //        else if (logInState == "incorrect user identifier")
                //        {
                //            //Console.WriteLine("Incorrect Username or Email Adress!");
                //            Console.WriteLine("Incorrect Username or Password!");//for more user security
                //            Thread.Sleep(1000);
                //            //Console.ReadLine();
                //        }
                //    }
                //    //reset the parameters to draw again the log in or sign up menue
                //    mainGround.ResetState();
                //    temp = "";
                //    Console.Clear();
                //}
                //clear the console window after a succesful log in
                Console.Clear();
                //draw the first ground
                mainGround.DrawAnSquare(babaee, apple);
                //while loop for continue the game
                while (babaee.GameOver() && !babaee.Win())// can be added --> && ReadKey.ConsoleReadKey() != "Escape"
                {
                    temp = ReadKey.ConsoleReadKey();

                    if (temp == "LeftArrow" || temp == "RightArrow")
                    {
                        babaee.HorizontalMove(temp);
                    }
                    if (temp == "UpArrow" || temp == "DownArrow")
                    {
                        babaee.VerticalMove(temp);
                    }

                    crashes.ObjectsCrash(babaee, apple, mainGround);

                    mainGround.DrawAnSquare(babaee, apple);
                }

                Console.Clear();
                //checking gameover or not for gameover message
                if (!babaee.GameOver())
                {
                    Console.Beep();
                    Console.WriteLine("Gameover!");
                }
                //checking winning or not for winning message
                else if (babaee.Win())
                {
                    Console.WriteLine("Congratulations!");
                    babaee.ResetScore();
                }
                //Waiting befor close the program
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
    }
}